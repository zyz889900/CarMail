#ifndef LOGIN_SIGNUP_H
#define LOGIN_SIGNUP_H

#include <QWidget>
#include <QRadioButton>
#include <QButtonGroup>
#include <QMouseEvent>
#include <QMessageBox>
#include <QApplication>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QtDebug>
#include <QtSql>

#include "mainmail.h"

namespace Ui {
    class Login_Signup;
}

class Login_Signup : public QWidget
{
    Q_OBJECT

public:
    explicit Login_Signup(QWidget *parent = nullptr);
    ~Login_Signup();

private slots:
    void on_pushButton_clicked();
    void on_pushButton_2_clicked();
    void on_pushButton_3_clicked();
    void on_pushButton_4_clicked();
    void on_radioButton_clicked();
    void receiveMainMail();
private:
    bool eventFilter(QObject *obj, QEvent *event);  //利用eventFilter来过滤
signals:
    void showMainMail();
public:
    bool connect_mysql();
private:
    Ui::Login_Signup *ui;
    QObject *obj;
    QSqlDatabase db;
};

#endif // LOGIN_SIGNUP_H
