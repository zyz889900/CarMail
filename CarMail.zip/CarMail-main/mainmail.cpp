/* 车载导航系统
 * 组号：第二组
 * 主界面（菜单界面）
 *
 *
 *
 */
#include "mainmail.h"
#include "ui_mainmail.h"

MainMail::MainMail(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::MainMail)
{
    ui->setupUi(this);
    ui->label->hide();
    ui->label_2->hide();
    ui->label_3->hide();
    ui->lineEdit->hide();
    ui->lineEdit_2->hide();
    ui->pushButton_7->hide();
    ui->pushButton_8->hide();
    ui->plainTextEdit->hide();
    ui->verticalScrollBar->hide();
    ui->listView()->hide();
}

void MainMail::receiveLogin(){
    this->show();
}

MainMail::~MainMail()
{
    delete ui;
}

void MainMail::on_pushButton_clicked()  //显示写邮件的界面
{
    ui->label->show();
    ui->label_2->show();
    ui->label_3->show();
    ui->lineEdit->show();
    ui->lineEdit_2->show();
    ui->pushButton_7->show();
    ui->pushButton_8->show();
    ui->plainTextEdit->show();
    ui->verticalScrollBar->show();

}

void MainMail::on_pushButton_6_clicked()  //退出登录
{
    this->hide();
    emit showLogin_Signup();
}


void MainMail::on_listView_clicked(const QModelIndex &index)
{

}
