#ifndef MAINMAIL_H
#define MAINMAIL_H

#include <QWidget>
#include "login_signup.h"

namespace Ui {
class MainMail;
}

class MainMail : public QWidget
{
    Q_OBJECT

public:
    explicit MainMail(QWidget *parent = nullptr);
    ~MainMail();
private slots:
    void receiveLogin();
    void on_pushButton_6_clicked();
    void on_pushButton_clicked();
signals:
    void showLogin_Signup();
private:
    Ui::MainMail *ui;
};

#endif // MAINMAIL_H
