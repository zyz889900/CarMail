﻿/* 车载导航系统
 * 开发组号：第二组
 * 登录注册界面
 * 登录注册界面在同一窗口下，通过控件的show()和hide()函数来进行选择性出现
 */
#include "login_signup.h"
#include "ui_login_signup.h"
#include "mainmail.h"
#define ip "127.0.0.1"
#define port 8888
//当界面出现时的窗体情况
Login_Signup::Login_Signup(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Login_Signup)
{
    ui->setupUi(this);
    ui->label_6->installEventFilter(this);  //安装eventFilter
    ui->label_6->setMouseTracking(true);  //label_6鼠标追踪
    ui->label_5->hide();
    ui->label_6->hide();
    ui->label_7->hide();
    ui->label_8->hide();
    ui->lineEdit_3->hide();
    ui->lineEdit_4->hide();
    ui->pushButton_3->hide();
    ui->pushButton_4->hide();
    ui->radioButton->hide();
    //创建socket对象
    socket=new QTcpSocket();
    connectServer();
}

Login_Signup::~Login_Signup()
{
    delete ui;
}

//与服务器建立连接
void Login_Signup::connectServer(){
    socket->abort();
    socket->connectToHost(ip,port);
    connect(socket,SIGNAL(readyRead()),this,SLOT(readMessage()));
    qDebug()<<"服务器建立连接成功";
}

//读取服务器返回的数据
void Login_Signup::readMessage(void){
    qDebug()<<"能收到消息吗？";
    QString data=socket->readAll();
    qDebug()<<data;
    QStringList list=data.split("#");
    if(list[0] == "login"){
        if(list[1] == "true"){
            QMessageBox::information(0,QString::fromStdString("登录成功"),QString::fromStdString("登录成功"));
            this->hide();
            emit showMainMail();
        }else if(list[1] == "false"){
            QMessageBox::warning(0,QString::fromStdString("登录失败"),QString::fromStdString("请检查用户名和密码"));
        }
    }
    else if(list[0] == "signup"){
        if(list[1]=="true"){
            QMessageBox::information(0,QString::fromStdString("注册成功"),QString::fromStdString("注册成功"));
        }else if(list[1]=="false"){
            QMessageBox::warning(0,QString::fromStdString("注册失败"),QString::fromStdString("注册失败"));
        }
    }
    else{
        qDebug()<<"Failed";
    }
}

void Login_Signup::receiveMainMail(){
    this->show();
}

bool Login_Signup::eventFilter(QObject *obj, QEvent *event){  //条款点击阅读
    if (obj == ui->label_6)//指定某个QLabel
     {
         if (event->type() == QEvent::MouseButtonPress) //鼠标点击
         {
             QMouseEvent *mouseEvent = static_cast<QMouseEvent*>(event); // 事件转换
             if(mouseEvent->button() == Qt::LeftButton)
             {
                 QMessageBox::information(0,QString::fromStdString("没有条款"),QString::fromStdString("    看NM，赶紧同意！        "));
                 return true;
             }
             else
             {
                 return false;
             }
         }
         else
         {
             return false;
         }
     }
     else
     {
         // pass the event on to the parent class
         return QWidget::eventFilter(obj, event);
     }
}

//槽函数（事件监听）
void Login_Signup::on_pushButton_clicked()  //进入主界面
{
    QString id=ui->lineEdit->text();
    QString password=ui->lineEdit_2->text();
    QString bs="login";
    QString data=bs+'#'+id+'#'+password;
    socket->write(data.toUtf8().data());
    socket->flush();
}

void Login_Signup::on_pushButton_2_clicked()  //注册界面
{
    this->setWindowTitle("注册界面");
    ui->label->hide();
    ui->label_2->hide();
    ui->label_3->hide();
    ui->label_4->hide();
    ui->label_5->show();
    ui->label_6->show();
    ui->label_7->show();
    ui->label_8->show();
    ui->lineEdit->hide();
    ui->lineEdit_2->hide();
    ui->lineEdit_3->show();
    ui->lineEdit_4->show();
    ui->pushButton->hide();
    ui->pushButton_2->hide();
    ui->pushButton_3->show();
    ui->pushButton_4->show();
    ui->radioButton->show();
}

void Login_Signup::on_pushButton_3_clicked()  //注册界面返回
{
    this->setWindowTitle("欢迎进入车载邮箱系统");
    ui->label->show();
    ui->label_2->show();
    ui->label_3->show();
    ui->label_4->show();
    ui->label_5->hide();
    ui->label_6->hide();
    ui->label_7->hide();
    ui->label_8->hide();
    ui->lineEdit->show();
    ui->lineEdit_2->show();
    ui->lineEdit_3->hide();
    ui->lineEdit_4->hide();
    ui->pushButton->show();
    ui->pushButton_2->show();
    ui->pushButton_3->hide();
    ui->pushButton_4->hide();
    ui->radioButton->hide();
}

void Login_Signup::on_pushButton_4_clicked()  //确认注册
{
    QString id=ui->lineEdit_3->text();
    QString password=ui->lineEdit_4->text();
    QString bs="signup";
    QString data=bs+'#'+id+'#'+password;
    socket->write(data.toLatin1());
    socket->flush();
}

void Login_Signup::on_radioButton_clicked()  //单选框控制确认注册按钮
{
    if(ui->radioButton->isChecked()){
        ui->pushButton_4->setEnabled(true);
    } else{
        ui->pushButton_4->setEnabled(false);
    }
}
