#include "login_signup.h"
#include "mainmail.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    Login_Signup ls;
    MainMail m;
    ls.show();
    QObject::connect(&ls,SIGNAL(showMainMail()),&m,SLOT(receiveLogin()));
    QObject::connect(&m,SIGNAL(showLogin_Signup()),&ls,SLOT(receiveMainMail()));
    return a.exec();
}
