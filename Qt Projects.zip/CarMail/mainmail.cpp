﻿#include "mainmail.h"
#include "ui_mainmail.h"
#include "login_signup.h"
MainMail::MainMail(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::MainMail)
{
    ui->setupUi(this);
    mainmailui();
}

void MainMail::createsocket(){
    socket=new QTcpSocket();
    connectServer();
}

//与服务器建立连接
void MainMail::connectServer(){
    socket->abort();
    socket->connectToHost("127.0.0.1",8888);
    connect(socket,SIGNAL(readyRead()),this,SLOT(readMessage()));
    qDebug()<<"服务器建立连接成功2";
}

//读取服务器返回的数据
void MainMail::readMessage(void){
    QString data=socket->readAll();
    QStringList list=data.split("`");

    if(list[0] == "userid"){
        userid = list[1];
    }
    else if(list[0] == "writemail"){
        if(list[1] == "true")
            QMessageBox::information(0,QString::fromStdString("发送成功"),QString::fromStdString("发送成功"));
        else
            QMessageBox::information(0,QString::fromStdString("发送失败"),QString::fromStdString("发送失败"));
    }
    else if(list[0] == "receivemail"){
        ui->listWidget->addItem("   发件人:\t"+list[1]+"\t\t\t\t主题:\t"+list[2]);
    }
    else if(list[0] == "rmail"){
        ui->textBrowser->setText(list[1]);
        ui->textBrowser_2->setText(list[2]);
        ui->textBrowser_3->setText(list[3]);
    }
    else{
        qDebug()<<"Failed";
    }
}

void MainMail::mainmailui(){
    ui->label->hide();
    ui->label_2->hide();
    ui->label_3->hide();
    ui->label_4->hide();
    ui->lineEdit->hide();
    ui->lineEdit_2->hide();
    ui->lineEdit_3->hide();
    ui->lineEdit_4->hide();
    ui->pushButton_7->hide();
    ui->pushButton_8->hide();
    ui->plainTextEdit->hide();
    ui->plainTextEdit_2->hide();
    ui->textBrowser->hide();
    ui->textBrowser_2->hide();
    ui->textBrowser_3->hide();
    ui->listWidget->hide();
}

void MainMail::receiveLogin(){
    this->show();
}

MainMail::~MainMail()
{
    delete ui;
}

void MainMail::on_pushButton_clicked()  //显示写邮件的界面
{
    mainmailui();
    ui->label->show();
    ui->label_2->show();
    ui->label_3->show();
    ui->lineEdit->show();
    ui->lineEdit_2->show();
    ui->pushButton_7->show();
    ui->pushButton_8->show();
    ui->plainTextEdit->show();
}

void MainMail::on_pushButton_2_clicked()  //收件箱
{
    mainmailui();
    ui->listWidget->clear();
    ui->listWidget->show();
    QString bs="receivemail";
    QString data=bs+'`'+userid;
    socket->write(data.toLatin1());
}

void MainMail::on_pushButton_3_clicked()
{
    mainmailui();
    ui->label->show();
    ui->label_2->show();
    ui->label_3->show();
    ui->lineEdit_3->show();
    ui->lineEdit_4->show();
    ui->plainTextEdit_2->show();
}

void MainMail::on_pushButton_4_clicked()
{
    mainmailui();
}

void MainMail::on_pushButton_5_clicked()
{
    mainmailui();
}

void MainMail::on_pushButton_6_clicked()  //退出登录
{
    this->hide();
    emit showLogin_Signup();
}

void MainMail::on_pushButton_7_clicked()  //写邮件中的发送按钮
{
    QString receivename=ui->lineEdit->text();
    QString title=ui->lineEdit_2->text();
    QString maintext=ui->plainTextEdit->toPlainText();
    QString bs="writemail";
    QString data=bs+'`'+receivename+'`'+userid+'`'+title+'`'+maintext;
    socket->write(data.toUtf8().data());
    socket->flush();
    qDebug()<<"发送功能正常";
}

void MainMail::on_pushButton_8_clicked()
{

}
void MainMail::on_listWidget_itemDoubleClicked(QListWidgetItem *item)
{
    ui->listWidget->hide();
    ui->textBrowser->show();
    ui->textBrowser_2->show();
    ui->textBrowser_3->show();
    ui->label_2->show();
    ui->label_3->show();
    ui->label_4->show();
    QString it=ui->listWidget->currentItem()->text();
    QStringList str=it.split("\t");
    QString bs="rmail";
    QString data=bs+'`'+userid+'`'+str[1]+'`'+str[6];
    socket->write(data.toUtf8().data());
}
