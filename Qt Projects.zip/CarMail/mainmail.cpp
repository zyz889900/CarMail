/* ??????
 * ??????
 * ?????????
 *
 *
 *
 */
#include "mainmail.h"
#include "ui_mainmail.h"
#include "login_signup.h"
MainMail::MainMail(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::MainMail)
{
    ui->setupUi(this);
    //????????
    QStandardItem *item = new QStandardItem("测试邮件");
    model->appendRow(item);
    ui->listView->setModel(model);
    mainmailui();
}

void MainMail::mainmailui(){
    //?????
    ui->label->hide();
    ui->label_2->hide();
    ui->label_3->hide();
    ui->label_4->hide();
    ui->lineEdit->hide();
    ui->lineEdit_2->hide();
    ui->lineEdit_3->hide();
    ui->lineEdit_4->hide();
    ui->pushButton_7->hide();
    ui->pushButton_8->hide();
    ui->plainTextEdit->hide();
    ui->plainTextEdit_2->hide();
    ui->textBrowser->hide();
    ui->textBrowser_2->hide();
    ui->textBrowser_3->hide();
    ui->listView->hide();
}

void MainMail::receiveLogin(){
    this->show();
}

MainMail::~MainMail()
{
    delete ui;
}

void MainMail::on_pushButton_clicked()  //显示写邮件的界面
{
    mainmailui();
    ui->label->show();
    ui->label_2->show();
    ui->label_3->show();
    ui->lineEdit->show();
    ui->lineEdit_2->show();
    ui->pushButton_7->show();
    ui->pushButton_8->show();
    ui->plainTextEdit->show();
}

void MainMail::on_pushButton_2_clicked()
{
    mainmailui();

    ui->listView->show();
    /*ui->textBrowser->show();
    ui->textBrowser_2->show();
    ui->textBrowser_3->show();
    ui->label_2->show();
    ui->label_3->show();
    ui->label_4->show();*/
}

void MainMail::on_pushButton_3_clicked()
{
    mainmailui();
    ui->label->show();
    ui->label_2->show();
    ui->label_3->show();
    ui->lineEdit_3->show();
    ui->lineEdit_4->show();
    ui->plainTextEdit_2->show();
}

void MainMail::on_pushButton_4_clicked()
{
    mainmailui();
}

void MainMail::on_pushButton_5_clicked()
{
    mainmailui();
}

void MainMail::on_pushButton_6_clicked()  //退出登录
{
    this->hide();
    emit showLogin_Signup();
}

void MainMail::on_pushButton_7_clicked()
{

}

void MainMail::on_pushButton_8_clicked()
{

}
