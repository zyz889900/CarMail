#ifndef MAINMAIL_H
#define MAINMAIL_H

#include <QWidget>
#include <QRadioButton>
#include <QApplication>
#include <QTextBrowser>
#include <QStandardItemModel>

namespace Ui {
class MainMail;
}

class MainMail : public QWidget
{
    Q_OBJECT

public:
    explicit MainMail(QWidget *parent = nullptr);
    ~MainMail();
    void mainmailui();
private slots:
    void receiveLogin();
    void on_pushButton_clicked();
    void on_pushButton_2_clicked();
    void on_pushButton_3_clicked();
    void on_pushButton_4_clicked();
    void on_pushButton_5_clicked();
    void on_pushButton_6_clicked();
    void on_pushButton_7_clicked();
    void on_pushButton_8_clicked();

signals:
    void showLogin_Signup();
private:
    Ui::MainMail *ui;
    QStandardItemModel *model = new QStandardItemModel(this);
};
#endif

