﻿#ifndef MAINMAIL_H
#define MAINMAIL_H

#include <QWidget>
#include <QRadioButton>
#include <QApplication>
#include <QTextBrowser>
#include <QStandardItemModel>
#include <QTcpServer>
#include <QTcpSocket>
namespace Ui {
class MainMail;
}

class MainMail : public QWidget
{
    Q_OBJECT

public:
    explicit MainMail(QWidget *parent = nullptr);
    ~MainMail();
    void mainmailui();
    void connectServer();
private slots:
    void receiveLogin();
    void createsocket();
    void on_pushButton_clicked();
    void on_pushButton_2_clicked();
    void on_pushButton_3_clicked();
    void on_pushButton_4_clicked();
    void on_pushButton_5_clicked();
    void on_pushButton_6_clicked();
    void on_pushButton_7_clicked();
    void on_pushButton_8_clicked();
    void readMessage();
signals:
    void showLogin_Signup();
private:
    Ui::MainMail *ui;
    QStandardItemModel *model = new QStandardItemModel(this);
    QObject *obj;
    QTcpSocket *socket;
    quint16 blockSize;
    QString userid;
};
#endif

