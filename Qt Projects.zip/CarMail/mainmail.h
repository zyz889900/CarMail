﻿#ifndef MAINMAIL_H
#define MAINMAIL_H

#include <QWidget>
#include <QRadioButton>
#include <QApplication>
#include <QTextBrowser>
#include <QListWidget>
#include <QTcpServer>
#include <QTcpSocket>
#include <QMenu>
namespace Ui {
class MainMail;
}

class MainMail : public QWidget
{
    Q_OBJECT

public:
    explicit MainMail(QWidget *parent = nullptr);
    ~MainMail();
    void mainmailui();
    void connectServer();
private slots:
    void receiveLogin();
    void createsocket();
    void on_pushButton_clicked();
    void on_pushButton_2_clicked();
    void on_pushButton_3_clicked();
    void on_pushButton_6_clicked();
    void on_pushButton_7_clicked();
    void on_pushButton_8_clicked();
    void readMessage();
    void on_listWidget_itemDoubleClicked(QListWidgetItem *item);
    void on_listWidget_2_itemDoubleClicked(QListWidgetItem *item);
    void on_pushButton_9_clicked();
    void on_listWidget_customContextMenuRequested(const QPoint &pos);
    void on_listWidget_2_customContextMenuRequested(const QPoint &pos);
    void deleteSeedSlot();
    void deleteSeedSlot2();
signals:
    void showLogin_Signup();
    void testclose2();
private:
    Ui::MainMail *ui;
    QObject *obj;
    QTcpSocket *socket;
    quint16 blockSize;
    QString userid;
    QString sender;
    QString title;

};
#endif

