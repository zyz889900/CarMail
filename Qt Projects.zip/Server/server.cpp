﻿#include "server.h"
#include "ui_server.h"

Server::Server(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::Server)
{
    ui->setupUi(this);
    db = QSqlDatabase::addDatabase("QMYSQL");  //连接的MYSQL的数据库驱动
    db.setHostName("localhost");         //主机名
    db.setPort(3306);                    //端口
    db.setDatabaseName("carmail");       //数据库名
    db.setUserName("root");              //用户名
    db.setPassword("123456");
    server = new QTcpServer();
    server->listen(QHostAddress("127.0.0.1"),8888);
    QTcpServer::connect(server,SIGNAL(newConnection()),this,SLOT(getConnection()));
    qDebug()<<"run the server";
}

Server::~Server()
{
    delete ui;
}

void Server::getConnection(){
    qDebug()<<"get the client data!";
    socket = server->nextPendingConnection();
    QTcpServer::connect(socket,SIGNAL(readyRead()),this,SLOT(readMessage()));
}

void Server::readMessage(){
    QString data = socket->readAll();
    qDebug()<<data;
    QStringList list=data.split("#");
    bool ret=false;
    QString ret1="";
    QString user;
    if(list[0]=="login"){
        ret=login(list[1],list[2]);
    }else if(list[0]=="signup"){
        ret=signup(list[1],list[2]);
    }




    QString sendData=list[0];
    if(ret){
        sendData+="#true";
        if(list[0]=="login"){
            user_id=list[1];
        }
    }else{
        sendData+="#false";
    }
    socket->write(sendData.toLatin1());
}

bool Server::login(QString id,QString password){
    if(!db.open())
    {
        qDebug()<<QString::fromStdString("不能连接")<<endl;
        return false;
    }
    else
    {
        qDebug()<<QString::fromStdString("连接成功")<<endl;
        QSqlQuery query(db);
        query.exec("SELECT * FROM user WHERE id='"+id+"' AND password='"+password+"';");
        if(query.next()){
            return true;
        }
        else{
            return false;
        }
    }
}

bool Server::signup(QString id,QString password){
    if(!db.open()){
        qDebug()<<QString::fromStdString("不能连接")<<endl;
        return false;
    }
    else{
        QSqlQuery query(db);
        bool ok = query.exec("INSERT INTO user VALUES('"+id+"','"+password+"');");
        if(!ok){
            //QMessageBox::information(0,QString::fromStdString("注册失败"),QString::fromStdString("注册失败"));
            return false;
        }
        else{
            //QMessageBox::information(0,QString::fromStdString("注册成功"),QString::fromStdString("注册成功"));
            return true;
        }
    }
}
