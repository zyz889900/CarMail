﻿#include "server.h"
#include "ui_server.h"

Server::Server(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::Server)
{
    ui->setupUi(this);
    db = QSqlDatabase::addDatabase("QMYSQL");  //连接的MYSQL的数据库驱动
    db.setHostName("localhost");         //主机名
    db.setPort(3306);                    //端口
    db.setDatabaseName("carmail");       //数据库名
    db.setUserName("root");              //用户名
    db.setPassword("123456");
    server = new QTcpServer();
    server->listen(QHostAddress("127.0.0.1"),8888);
    QTcpServer::connect(server,SIGNAL(newConnection()),this,SLOT(getConnection()));
    qDebug()<<"run the server";
}

Server::~Server()
{
    delete ui;
}

void Server::getConnection(){
    qDebug()<<"get the client data!";
    socket = server->nextPendingConnection();
    QTcpServer::connect(socket,SIGNAL(readyRead()),this,SLOT(readMessage()));
    if(user_id!=""){
        QString data="userid";
        data+="`";
        data+=user_id;
        socket->write(data.toLatin1());
    }
}

void Server::readMessage(){
    QString data = socket->readAll();
    qDebug()<<data;
    QStringList list=data.split("`");
    bool ret=false;
    QString user;
    if(list[0]=="login"){
        ret=login(list[1],list[2]);
        QString sendData=list[0];
        if(ret){
            sendData+="`true";
            sendData+="`";
            sendData+=list[1];
            if(list[0]=="login"){
                user_id=list[1];
            }

        }else{
            sendData+="`false";
        }
        socket->write(sendData.toLatin1());
    }else if(list[0]=="signup"){
        ret=signup(list[1],list[2]);
        QString sendData=list[0];
        if(ret){
            sendData+="`true";
            sendData+="`";
            sendData+=list[1];
            if(list[0]=="login"){
                user_id=list[1];
            }

        }else{
            sendData+="`false";
        }
        socket->write(sendData.toLatin1());
    }else if(list[0]=="writemail"){
        writemail(list[1],list[2],list[3],list[4]);
    }else if(list[0]=="receivemail"){
        receivemail(list[1]);
    }else if(list[0]=="rmail"){
        rmail(list[1],list[2],list[3]);
    }else if (list[0]=="cmail") {
        cmail(list[1],list[2],list[3],list[4]);
    }else if(list[0]=="c2q"){
        crmail(list[1]);
    }else if (list[0]=="c3q") {
        c3q(list[1],list[2],list[3]);
    }else if(list[0]=="cfs"){
        cfs(list[1],list[2],list[3],list[4]);
    }else if(list[0]=="deletemail"){
        deletemail(list[1],list[2],list[3]);
    }else if(list[0]=="deletemail2"){
        deletemail2(list[1],list[2],list[3]);
    }
    else{
        qDebug()<<"Error";
    }
}

bool Server::login(QString id,QString password){
    if(!db.open())
    {
        qDebug()<<QString::fromStdString("不能连接")<<endl;
        return false;
    }
    else
    {
        qDebug()<<QString::fromStdString("连接成功")<<endl;
        QSqlQuery query(db);
        query.exec("SELECT * FROM user WHERE id='"+id+"' AND password='"+password+"';");
        if(query.next()){
            return true;
        }
        else{
            return false;
        }
    }
}

bool Server::signup(QString id,QString password){
    if(!db.open()){
        qDebug()<<QString::fromStdString("不能连接")<<endl;
        return false;
    }
    else{
        QSqlQuery query(db);
        bool ok = query.exec("INSERT INTO user VALUES('"+id+"','"+password+"');");
        if(!ok){
            return false;
        }
        else{
            return true;
        }
    }
}

void Server::writemail(QString receiveman,QString sender,QString title,QString maintext){
    db.open();
    QSqlQuery query(db);
    query.exec("INSERT INTO mailbox(mailfrom,mailsender,mailtitle,mailcontent) VALUES('"+receiveman+"','"+sender+"','"+title+"','"+maintext+"');");
}

void Server::receivemail(QString receiveman){
    db.open();
    QSqlQuery query(db);
    query.exec("SELECT mailsender,mailtitle FROM mailbox WHERE mailfrom='"+receiveman+"';");
    while(query.next()){
        QString str1,str2,strall;
        str1=query.value(0).toString();
        str2=query.value(1).toString();
        strall="receivemail`"+str1+'`'+str2;
        socket->write(strall.toLatin1());
        int i = 10000000;
        while(i){
            i--;
        }
        socket->flush();
        //qDebug()<<strall<<endl;
        strall="";
    }
}

void Server::rmail(QString receiveman,QString sender,QString title){
    db.open();
    QSqlQuery query(db);
    query.exec("SELECT mailcontent FROM mailbox WHERE mailfrom='"+receiveman+"' AND mailsender='"+sender+"' AND mailtitle='"+title+"';");
    if(query.next()){
        QString str1,strall;
        str1=query.value(0).toString();
        strall="rmail`"+sender+'`'+title+'`'+str1;
        socket->write(strall.toLatin1());
        socket->flush();
        strall="";
    }
}

void Server::cmail(QString receiveman,QString sender,QString title,QString maintext){
    db.open();
    QSqlQuery query(db);
    query.exec("INSERT INTO cbox(mailfrom,mailsender,mailtitle,mailcontent) VALUES('"+receiveman+"','"+sender+"','"+title+"','"+maintext+"');");
}

void Server::crmail(QString sender){
    db.open();
    QSqlQuery query(db);
    qDebug()<<"找数据";
    query.exec("SELECT mailfrom,mailtitle FROM cbox WHERE mailsender='"+sender+"';");
    while(query.next()){
        QString str1,str2,strall;
        str1=query.value(0).toString();
        str2=query.value(1).toString();
        strall="c2q`"+str1+'`'+str2;
        socket->write(strall.toLatin1());
        int i = 10000000;
        while(i){
            i--;
        }
        socket->flush();
        strall="";
    }
}

void Server::c3q(QString sender,QString receiveman,QString title){
    db.open();
    QSqlQuery query(db);
    query.exec("SELECT mailcontent FROM cbox WHERE mailfrom='"+receiveman+"' AND mailsender='"+sender+"' AND mailtitle='"+title+"';");
    if(query.next()){
        QString str1,strall;
        str1=query.value(0).toString();
        strall="c3q`"+receiveman+'`'+title+'`'+str1;
        socket->write(strall.toLatin1());
        socket->flush();
        qDebug()<<strall<<endl;
        strall="";
    }
}

void Server::cfs(QString receiveman,QString sender,QString title,QString maintext){
    db.open();
    QSqlQuery query(db);
    query.exec("DELETE FROM cbox WHERE mailfrom='"+receiveman+"' AND mailsender='"+sender+"' AND mailtitle='"+title+"';");
    query.exec("INSERT INTO cbox(mailfrom,mailsender,mailtitle,mailcontent) VALUES('"+receiveman+"','"+sender+"','"+title+"','"+maintext+"');");
}

void Server::deletemail(QString receiveman,QString sender,QString title){
    db.open();
    QSqlQuery query(db);
    query.exec("DELETE FROM mailbox WHERE mailfrom='"+receiveman+"' AND mailsender='"+sender+"' AND mailtitle='"+title+"';");
}

void Server::deletemail2(QString receiveman,QString sender,QString title){
    db.open();
    QSqlQuery query(db);
    query.exec("DELETE FROM cbox WHERE mailfrom='"+receiveman+"' AND mailsender='"+sender+"' AND mailtitle='"+title+"';");
}
