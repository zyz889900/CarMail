﻿#ifndef SERVER_H
#define SERVER_H

#include <QMainWindow>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QtDebug>
#include <QtSql>
#include <QTcpServer>
#include <QTcpSocket>
#include <QString>
#include <QObject>
#include <QMessageBox>
#include <string>
namespace Ui {
class Server;
}

class Server : public QMainWindow
{
    Q_OBJECT

public:
    explicit Server(QWidget *parent = nullptr);
    bool login(QString id,QString password);
    bool signup(QString id,QString password);
    void writemail(QString receiveman,QString sender,QString title,QString maintext);
    void receivemail(QString receiveman);
    ~Server();
private slots:
    void getConnection();
    void readMessage();

private:
    Ui::Server *ui;
    QSqlDatabase db;
    QTcpServer *server;
    QTcpSocket *socket;
    QString user_id="";
};

#endif // SERVER_H
